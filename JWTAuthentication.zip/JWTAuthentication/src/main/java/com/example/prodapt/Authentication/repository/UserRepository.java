package com.example.prodapt.Authentication.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.prodapt.Authentication.entity.User;

public interface UserRepository extends CrudRepository<User, Long> {

	

	User findByUserName(String username);

	User findByEmail(String username);

}
