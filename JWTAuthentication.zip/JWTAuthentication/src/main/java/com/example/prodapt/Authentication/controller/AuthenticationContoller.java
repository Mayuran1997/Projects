package com.example.prodapt.Authentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.prodapt.Authentication.entity.AuthRequest;
import com.example.prodapt.Authentication.entity.User;
import com.example.prodapt.Authentication.utils.JwtTokenUtil;

@RestController
@CrossOrigin
public class AuthenticationContoller {

	@Autowired
	private JwtTokenUtil jwtTokenUtil;
	@Autowired
	private AuthenticationManager authenticationManager;
	
	private User userdetails;
	@GetMapping("/") 
	public String Hello() {
		return "Welcome";
	}
	
	
	@PostMapping("/authenticate")
	public String generateToken(@RequestBody AuthRequest authrequest) throws Exception {
		
		 try {
			 authenticationManager.authenticate(
					 new UsernamePasswordAuthenticationToken(authrequest.getUserName(), authrequest.getPassword())
					 );
		 }
		 catch (Exception e) {
			throw new Exception("Invalid Username or Password");
		}
		return jwtTokenUtil.generateToken(authrequest.getUserName());
	}
}
