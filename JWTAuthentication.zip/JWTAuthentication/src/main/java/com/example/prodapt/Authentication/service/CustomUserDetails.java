package com.example.prodapt.Authentication.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.security.core.userdetails.User;
import com.example.prodapt.Authentication.repository.UserRepository;

@Service
public class CustomUserDetails implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		com.example.prodapt.Authentication.entity.User user=userRepository.findByEmail(username);
		
		return new User(user.getEmail(),user.getPassword(),new ArrayList<>()) ;
	}

}
